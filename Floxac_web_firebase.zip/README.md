Floxac — Simple Web Version with Firebase (Auth, Firestore, Storage, Chat)

How to use:
1. Create a Firebase project at https://console.firebase.google.com
2. Enable Authentication (Email/Password), Firestore (Native mode), and Storage.
3. Open firebase-config.js and replace the placeholders with your Firebase config values.
4. Serve the folder with a simple static server (or open index.html in a browser).
   For local dev with a simple server (recommended): `npx http-server -c-1` in the project folder
5. Register a new user, create posts and chats.

Security:
- This demo uses simple Firestore rules for development only. For production strict rules must be applied.
