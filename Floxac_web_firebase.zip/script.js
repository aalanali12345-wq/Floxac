// Floxac main script - uses Firebase compat SDK included in index.html
// Make sure firebase-config.js has correct values before using.

// DOM elements
const showLogin = document.getElementById('showLogin');
const showRegister = document.getElementById('showRegister');
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalName = document.getElementById('modalName');
const modalEmail = document.getElementById('modalEmail');
const modalPassword = document.getElementById('modalPassword');
const modalCancel = document.getElementById('modalCancel');
const modalSubmit = document.getElementById('modalSubmit');
const userInfo = document.getElementById('userInfo');
const displayNameEl = document.getElementById('displayName');
const logoutBtn = document.getElementById('logoutBtn');
const authButtons = document.getElementById('authButtons');
const createPostSection = document.getElementById('createPostSection');
const postCaption = document.getElementById('postCaption');
const postImage = document.getElementById('postImage');
const publishBtn = document.getElementById('publishBtn');
const feed = document.getElementById('feed');

const openMessages = document.getElementById('openMessages');
const chatSection = document.getElementById('chatSection');
const chatsList = document.getElementById('chatsList');
const messagesBox = document.getElementById('messagesBox');
const chatText = document.getElementById('chatText');
const sendMsg = document.getElementById('sendMsg');

let currentUser = null;
let activeChatId = null;

// Show login/register modal
showLogin.addEventListener('click', ()=> openModal('login'));
showRegister.addEventListener('click', ()=> openModal('register'));

function openModal(mode){
  modal.classList.remove('hidden');
  if(mode==='login'){
    modalTitle.textContent = 'Login';
    modalName.hidden = true;
    modalEmail.value = '';
    modalPassword.value = '';
    modalSubmit.dataset.mode = 'login';
  } else {
    modalTitle.textContent = 'Register';
    modalName.hidden = false;
    modalEmail.value = '';
    modalPassword.value = '';
    modalName.value = '';
    modalSubmit.dataset.mode = 'register';
  }
}

modalCancel.addEventListener('click', ()=> modal.classList.add('hidden'));

modalSubmit.addEventListener('click', async ()=>{
  const mode = modalSubmit.dataset.mode;
  const email = modalEmail.value.trim();
  const pass = modalPassword.value.trim();
  if(mode==='register'){
    const name = modalName.value.trim() || 'User';
    try{
      const res = await auth.createUserWithEmailAndPassword(email, pass);
      await res.user.updateProfile({ displayName: name });
      await db.collection('users').doc(res.user.uid).set({ displayName: name, email, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
      modal.classList.add('hidden');
    }catch(e){ alert('Register error: '+e.message) }
  } else {
    try{
      await auth.signInWithEmailAndPassword(email, pass);
      modal.classList.add('hidden');
    }catch(e){ alert('Login error: '+e.message) }
  }
});

logoutBtn.addEventListener('click', ()=> auth.signOut());

// Auth state listener
auth.onAuthStateChanged(user => {
  currentUser = user;
  if(user){
    displayNameEl.textContent = user.displayName || user.email;
    userInfo.hidden = false;
    authButtons.hidden = true;
    createPostSection.hidden = false;
    loadStories();
    subscribePosts();
    loadChats();
  } else {
    userInfo.hidden = true;
    authButtons.hidden = false;
    createPostSection.hidden = true;
    feed.innerHTML = '';
    chatsList.innerHTML = '';
  }
});

// Publish post
publishBtn.addEventListener('click', async ()=>{
  if(!currentUser){ alert('Please login'); return; }
  const file = postImage.files[0];
  const caption = postCaption.value.trim();
  if(!file){ alert('Choose an image'); return; }
  const storageRef = storage.ref('posts/'+Date.now()+'_'+file.name);
  const uploadTask = storageRef.put(file);
  uploadTask.on('state_changed', null, err=> alert('Upload error: '+err.message), async ()=>{
    const url = await uploadTask.snapshot.ref.getDownloadURL();
    await db.collection('posts').add({
      userId: currentUser.uid,
      userName: currentUser.displayName || currentUser.email,
      caption,
      imageUrl: url,
      likes: 0,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    postCaption.value = '';
    postImage.value = '';
    alert('Posted');
  });
});

// Subscribe to posts (real-time)
let unsubscribePosts = null;
function subscribePosts(){
  if(unsubscribePosts) unsubscribePosts();
  unsubscribePosts = db.collection('posts').orderBy('createdAt','desc').onSnapshot(snapshot=>{
    feed.innerHTML = '';
    snapshot.forEach(doc => {
      const p = doc.data();
      const el = createPostElement(doc.id, p);
      feed.appendChild(el);
    });
  });
}

function createPostElement(id, post){
  const art = document.createElement('article');
  art.className = 'post';
  art.innerHTML = `
    <div class="post-header">
      <img class="avatar" src="${post.avatarUrl||('https://i.pravatar.cc/40')}">
      <div>
        <div style="color:var(--gold);font-weight:700">${post.userName}</div>
        <div style="color:#bbb;font-size:12px">${post.location||''}</div>
      </div>
      <button class="more">...</button>
    </div>
    ${post.imageUrl ? `<img class="post-img" src="${post.imageUrl}" alt="post">` : ''}
    <div class="actions">
      <div class="left"> <button class="likeBtn">❤</button> </div>
      <div class="right"></div>
    </div>
    <div class="likes">${post.likes||0} likes</div>
    <div class="desc"><strong>${post.userName}</strong> ${post.caption||''}</div>
    <button class="comments">View comments</button>
  `;
  const likeBtn = art.querySelector('.likeBtn');
  likeBtn.addEventListener('click', async ()=>{
    const ref = db.collection('posts').doc(id);
    await ref.update({ likes: (post.likes||0)+1 });
    if(post.userId && currentUser && post.userId !== currentUser.uid){
      await db.collection('notifications').add({ to: post.userId, from: currentUser.uid, type: 'like', postId: id, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
    }
  });
  return art;
}

// Stories (simple static)
function loadStories(){
  const names = ['You','Ali','Sara','Omar','Lina','Yousef'];
  const container = document.getElementById('storiesRow');
  container.innerHTML = '';
  names.forEach((n,i)=>{
    const s = document.createElement('div');
    s.className = 'story';
    s.innerHTML = `<img class="avatar" src="https://i.pravatar.cc/80?img=${i+10}"><p>${n}</p>`;
    container.appendChild(s);
  });
}

// Chat: simple create/join + messages
async function loadChats(){
  chatsList.innerHTML = '';
  const q = await db.collection('chats').where('participants','array-contains', currentUser.uid).get();
  q.forEach(doc=>{
    const data = doc.data();
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = data.title || ('Chat '+doc.id);
    btn.addEventListener('click', ()=> openChat(doc.id));
    chatsList.appendChild(btn);
  });
  const newChatBtn = document.createElement('button');
  newChatBtn.className = 'btn primary';
  newChatBtn.textContent = 'New chat (by email)';
  newChatBtn.addEventListener('click', ()=> createChatPrompt());
  chatsList.appendChild(newChatBtn);
}

async function createChatPrompt(){
  const email = prompt('Enter participant email to chat with:');
  if(!email) return;
  const users = await db.collection('users').where('email','==',email).get();
  if(users.empty){ alert('User not found'); return; }
  const u = users.docs[0];
  const participants = [currentUser.uid, u.id];
  const title = 'Chat with '+ (u.data().displayName || email);
  const chatDoc = await db.collection('chats').add({ participants, title, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
  loadChats();
  openChat(chatDoc.id);
}

function openChat(chatId){
  activeChatId = chatId;
  chatSection.hidden = false;
  messagesBox.innerHTML = 'Loading...';
  db.collection(`chats/${chatId}/messages`).orderBy('createdAt').onSnapshot(snap=>{
    messagesBox.innerHTML = '';
    snap.forEach(d=>{
      const m = d.data();
      const div = document.createElement('div');
      div.textContent = m.text;
      div.className = m.from===currentUser.uid ? 'my-msg' : 'their-msg';
      messagesBox.appendChild(div);
    });
    messagesBox.scrollTop = messagesBox.scrollHeight;
  });
}

sendMsg.addEventListener('click', async ()=>{
  if(!activeChatId) return alert('Open a chat first');
  const text = chatText.value.trim(); if(!text) return;
  await db.collection(`chats/${activeChatId}/messages`).add({ from: currentUser.uid, text, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
  chatText.value = '';
});

// small translator hint
function addTranslator(){
  const t = document.createElement('div');
  t.style.marginTop = '8px';
  t.innerHTML = '<button id="toAr" class="btn">Arabic</button> <button id="toEn" class="btn">English</button>';
  document.querySelector('.welcome-section').appendChild(t);
  document.getElementById('toAr').addEventListener('click', ()=> alert('You can use browser translate or Google translate for full localization.'));
  document.getElementById('toEn').addEventListener('click', ()=> alert('English selected.'));
}
addTranslator();

openMessages.addEventListener('click', ()=> chatSection.hidden = !chatSection.hidden);

console.log('Floxac script loaded');
