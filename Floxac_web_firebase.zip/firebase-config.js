// Paste your Firebase config here. Create a Firebase project and enable Auth/Firestore/Storage.
// Replace the values below with your project's values.
const firebaseConfig = {
  apiKey: "REPLACE_ME_API_KEY",
  authDomain: "REPLACE_ME_AUTH_DOMAIN",
  projectId: "REPLACE_ME_PROJECT_ID",
  storageBucket: "REPLACE_ME_STORAGE_BUCKET",
  messagingSenderId: "REPLACE_ME_MESSAGING_SENDER_ID",
  appId: "REPLACE_ME_APP_ID"
};

firebase.initializeApp(firebaseConfig);

// short handles for compat SDK
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();
